//
//  NetworkHandler.h
//  TopBlip
//
//  Created by Asif Noor on 2/23/13.
//
//

#import <Foundation/Foundation.h>

@interface NetworkHandler : NSObject
+(BOOL) checkInternet;
@end
