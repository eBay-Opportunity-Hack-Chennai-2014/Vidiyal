//
//  VidiyalHomeViewController.h
//  VidiyalFoundation
//
//  Created by iBeris Software Solutions Pvt. Ltd on 12/10/14.
//  Copyright (c) 2014 NGO. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface VidiyalHomeViewController : UIViewController <MFMailComposeViewControllerDelegate>

+ (VidiyalHomeViewController *)viewController;

@end
